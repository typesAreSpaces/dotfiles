# Alt-Ergo

Alt-Ergo is an automatic theorem prover of mathematical formulas. It
was developed at LRI, and is now maintained at OCamlPro:

See more details on http://alt-ergo.ocamlpro.com/


## Copyright

See enclosed COPYING.md file


## Build, Installation and Usage

See enclosed INSTALL.md file


## Support

See http://alt-ergo.ocamlpro.com/support.php or contact us at
contact@ocamlpro.com for more details
