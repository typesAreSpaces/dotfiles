# qTest

## Info:
The inline tests are generated and run here. The qTest code itself has moved to a new location:

 https://github.com/vincent-hugot/iTeML


## Files:
_tags : necessary to run the tests
