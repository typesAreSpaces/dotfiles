install.packages('svmpath', repos='http://cran.r-project.org')
