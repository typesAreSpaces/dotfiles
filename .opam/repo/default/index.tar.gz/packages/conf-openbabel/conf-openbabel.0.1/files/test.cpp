#include <openbabel/mol.h>

// compile with: c++ -I/usr/include/openbabel-2.0 test.c -lopenbabel

int main () {
  OpenBabel::OBMol mol;
  return 0;
}
